# FRUGLEY MATH LAB

A simple gaming and entertainment directory built with HTML, CSS, and JavaScript. Open `index.html` in a browser or publish it with GitHub Pages.
